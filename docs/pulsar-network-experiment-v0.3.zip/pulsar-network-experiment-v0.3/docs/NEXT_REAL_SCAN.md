# Next milestone: first frozen archival scan

The software experiment is ready for a real-data pilot. The next run must not tune thresholds after looking at candidate results.

## Pilot design

- Select 5–10 bright, well-characterized pulsars before downloading or inspecting pulse-level anomalies.
- Prefer search-mode data with individual rotations, broad frequency coverage and polarization.
- Include repeated observations and, where available, independent observatories.
- Use at least 4,000 surrogate realizations for a 10-target batch if a single candidate must be able to reach batch q < 0.01 under the current four-channel correction.
- Run the target, off-pulse, wrong-period, wrong-DM and block-permutation controls from the frozen manifest.
- Keep a held-out observation for recurrence testing.

## Escalation rule

A software anomaly is not announced as a technosignature. Escalation requires raw-data inspection, observatory/instrument review, off-source exclusion, predicted recurrence and independent telescope confirmation.
