# Pre-registration draft for the first public archival scan

This document must be versioned and frozen before examining the selected real-data results.

## Primary hypothesis

After correcting known propagation, instrument and RFI effects, at least one pulsar observation contains repeatable protocol-like structure not adequately reproduced by the registered natural surrogate ensemble.

## Null hypothesis

All detected structure is compatible with natural pulsar variability, interstellar propagation, terrestrial interference, instrumental effects, selection effects or the registered statistical models.

## Inclusion criteria

- Public search-mode or single-pulse data.
- Known source position, rotation period and dispersion measure.
- At least 10,000 usable rotations where practical.
- Time and frequency resolution sufficient to preserve individual pulses.
- Rawest available calibrated product retained.

## Exclusion criteria fixed before scanning

- Fewer than 16 complete rotations after preprocessing.
- More than 90% of channels rejected by the registered RFI mask.
- Corrupted/incomplete headers or inconsistent sample dimensions.
- Candidate appearing in off-pulse, wrong-period, wrong-DM, off-source or geographically local RFI controls.
- Candidate dependent on one undocumented preprocessing choice.

## Registered channels

1. pulse amplitude;
2. signed polarization proxy;
3. arrival-time residual;
4. frequency centroid.

No additional feature channel may be added after seeing candidate results without labeling the analysis exploratory.

## Registered detector

- Robust two-cluster binarization.
- Autocorrelation frame search from lag 32 to min(4096, N/3).
- Mixed Markov, run-length-permutation and circular block-bootstrap surrogate ensemble.
- Four-channel selection correction.
- Compression gain as a secondary metric.
- Benjamini-Hochberg correction across the target batch.

## Analysis thresholds

### Level 1 — software anomaly

- channel-adjusted p < 0.05;
- compression gain > 128 bits;
- survives the registered preprocessing sensitivity checks.

### Level 2 — follow-up candidate

- batch FDR q < 0.01 after an escalated surrogate run;
- compatible candidate lag in held-out split halves;
- recurrence in a held-out observation;
- no corresponding off-source/local RFI event;
- compatible structure in frequency or polarization sub-bands.

### Level 3 — technosignature candidate

- independent observatory confirmation;
- predicted recurrence succeeds;
- raw-data and instrument teams exclude known effects;
- recovered structure contains framing/redundancy or error-detection behavior.

### Level 4 — network evidence

- a statistically corrected, independently replicated shared protocol across at least three sky-separated pulsars;
- timing relationships compatible with a declared propagation/repeater model;
- no plausible common terrestrial or pipeline source.

No single-software detection will be described as proof of extraterrestrial intelligence.

## Negative result policy

A null result constrains only the tested modulation families, cadences, frequencies, datasets and detector sensitivity. It does not show that no extraterrestrial communication network exists.
