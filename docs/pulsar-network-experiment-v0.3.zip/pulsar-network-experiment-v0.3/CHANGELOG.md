# Changelog

## 0.3.0 — 2026-08-04

- Added manifest-driven archival experiments with SHA-256 provenance.
- Added off-pulse, wrong-period, wrong-DM and block-permutation negative controls.
- Added split-half recurrence checks and explicit candidate dispositions.
- Added circular block-bootstrap surrogates to preserve local natural texture.
- Added injection-recovery sensitivity analysis.
- Added persistent pulse-train metadata and three automated tests.
- Fixed cyclic frame recovery when a recovered packet wraps across the candidate period boundary.

## 0.2.0 — 2026-08-04

- Added multi-channel anomaly detection across amplitude, polarization, timing and frequency-centroid streams.
- Added mixed Markov/run-length natural surrogate ensemble and four-channel selection correction.
- Added generic repeated-frame consensus recovery and synthetic Manchester/CRC verification.
- Added HDF5, SIGPROC filterbank and optional PSRFITS ingestion adapters.
- Added incoherent dedispersion, robust RFI-channel masking and pulse-feature extraction.
- Added red-team benchmark families, batch FDR correction and a pre-registration draft.
- Added seven automated tests and release artifacts.
