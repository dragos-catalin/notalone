from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json
import math
import struct

import h5py
import numpy as np

from .models import PulseTrain


DISPERSION_CONSTANT_S_MHZ2 = 4.148808e3


@dataclass(slots=True)
class DynamicSpectrum:
    """Detected radio-power samples indexed as time × polarisation × frequency.

    The container deliberately stores calibrated/relative power, not raw voltages.
    It is suitable for first-pass single-pulse extraction from SIGPROC filterbank,
    Breakthrough Listen-style HDF5, or search-mode PSRFITS adapters.
    """

    data: np.ndarray
    tsamp_s: float
    frequencies_hz: np.ndarray
    source_id: str = "unknown"
    start_mjd: float | None = None
    metadata: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        arr = np.asarray(self.data)
        if arr.ndim == 2:
            arr = arr[:, None, :]
        if arr.ndim != 3:
            raise ValueError("data must have shape (time, frequency) or (time, polarisation, frequency)")
        if arr.shape[-1] != len(self.frequencies_hz):
            raise ValueError("frequency axis does not match frequencies_hz")
        if self.tsamp_s <= 0:
            raise ValueError("tsamp_s must be positive")
        self.data = arr.astype(np.float32, copy=False)
        self.frequencies_hz = np.asarray(self.frequencies_hz, dtype=float)
        self.metadata = dict(self.metadata or {})

    @property
    def n_time(self) -> int:
        return int(self.data.shape[0])

    @property
    def n_pol(self) -> int:
        return int(self.data.shape[1])

    @property
    def n_chan(self) -> int:
        return int(self.data.shape[2])

    def save_hdf5(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with h5py.File(path, "w") as handle:
            ds = handle.create_dataset("data", data=self.data, compression="gzip", shuffle=True)
            ds.attrs["tsamp"] = self.tsamp_s
            ds.attrs["source_name"] = self.source_id
            ds.attrs["frequencies_hz"] = self.frequencies_hz
            if self.start_mjd is not None:
                ds.attrs["tstart"] = self.start_mjd
            ds.attrs["pulsarnet_metadata_json"] = json.dumps(self.metadata)


def _attr(container: h5py.AttributeManager, *names: str, default: Any = None) -> Any:
    for name in names:
        if name in container:
            value = container[name]
            if isinstance(value, bytes):
                return value.decode("utf-8", errors="replace")
            if isinstance(value, np.ndarray) and value.size == 1:
                return value.reshape(-1)[0].item()
            return value
    return default


def load_hdf5_dynamic_spectrum(
    path: str | Path,
    *,
    start_sample: int = 0,
    max_samples: int | None = None,
) -> DynamicSpectrum:
    """Load a Breakthrough Listen-style or PulsarNet HDF5 dynamic spectrum.

    Common datasets named ``data`` or ``/data`` are supported. Frequency metadata
    may be explicit or reconstructed from ``fch1`` and ``foff`` in MHz.
    """

    path = Path(path)
    with h5py.File(path, "r") as handle:
        if "data" in handle:
            ds = handle["data"]
        else:
            datasets: list[h5py.Dataset] = []
            handle.visititems(lambda _name, obj: datasets.append(obj) if isinstance(obj, h5py.Dataset) else None)
            if not datasets:
                raise ValueError(f"No dataset found in {path}")
            ds = max(datasets, key=lambda item: item.size)

        stop = ds.shape[0] if max_samples is None else min(ds.shape[0], start_sample + max_samples)
        if start_sample < 0 or start_sample >= stop:
            raise ValueError("invalid sample range")
        data = np.asarray(ds[start_sample:stop])
        if data.ndim == 2:
            data = data[:, None, :]
        elif data.ndim == 3:
            # BL HDF5 normally uses time × IF/pol × frequency.
            pass
        else:
            raise ValueError(f"Unsupported HDF5 data shape {data.shape}")

        attrs = dict(handle.attrs)
        attrs.update(dict(ds.attrs))
        tsamp = float(_attr(attrs, "tsamp", "TBIN", default=0.0))
        if tsamp <= 0:
            raise ValueError("HDF5 file is missing a positive tsamp attribute")

        nchan = data.shape[-1]
        explicit = _attr(attrs, "frequencies_hz", "frequency_hz")
        if explicit is not None:
            freqs = np.asarray(explicit, dtype=float)
        else:
            fch1_mhz = _attr(attrs, "fch1")
            foff_mhz = _attr(attrs, "foff")
            if fch1_mhz is None or foff_mhz is None:
                raise ValueError("HDF5 file needs frequencies_hz or fch1/foff metadata")
            freqs = (float(fch1_mhz) + np.arange(nchan) * float(foff_mhz)) * 1e6

        source = str(_attr(attrs, "source_name", "source_id", "SRC_NAME", default=path.stem))
        start_mjd_raw = _attr(attrs, "tstart", "STT_IMJD")
        start_mjd = float(start_mjd_raw) if start_mjd_raw is not None else None
        metadata_json = _attr(attrs, "pulsarnet_metadata_json")
        metadata: dict[str, Any] = {"format": "hdf5", "path": str(path)}
        if metadata_json:
            try:
                metadata.update(json.loads(str(metadata_json)))
            except json.JSONDecodeError:
                metadata["metadata_parse_error"] = True

    return DynamicSpectrum(
        data=data,
        tsamp_s=tsamp,
        frequencies_hz=freqs,
        source_id=source,
        start_mjd=start_mjd,
        metadata=metadata,
    )


_SIGPROC_STRING_KEYS = {"rawdatafile", "source_name"}
_SIGPROC_INT_KEYS = {
    "machine_id", "telescope_id", "data_type", "barycentric", "pulsarcentric",
    "nbits", "nsamples", "nchans", "nifs", "nbeams", "ibeam", "sumifs", "signed",
}
_SIGPROC_DOUBLE_KEYS = {
    "az_start", "za_start", "src_raj", "src_dej", "tstart", "tsamp", "fch1", "foff",
    "refdm", "period",
}


def _read_sigproc_string(handle) -> str:
    raw = handle.read(4)
    if len(raw) != 4:
        raise EOFError("Unexpected EOF in SIGPROC header")
    length = struct.unpack("<i", raw)[0]
    if length < 0 or length > 1_000_000:
        raise ValueError(f"Invalid SIGPROC string length {length}")
    payload = handle.read(length)
    if len(payload) != length:
        raise EOFError("Unexpected EOF in SIGPROC string")
    return payload.decode("ascii", errors="replace")


def read_sigproc_header(path: str | Path) -> tuple[dict[str, Any], int]:
    path = Path(path)
    header: dict[str, Any] = {}
    with path.open("rb") as handle:
        start = _read_sigproc_string(handle)
        if start != "HEADER_START":
            raise ValueError("Not a SIGPROC filterbank file: HEADER_START missing")
        while True:
            key = _read_sigproc_string(handle)
            if key == "HEADER_END":
                return header, handle.tell()
            if key in _SIGPROC_STRING_KEYS:
                header[key] = _read_sigproc_string(handle)
            elif key in _SIGPROC_INT_KEYS:
                payload = handle.read(4)
                if len(payload) != 4:
                    raise EOFError("Unexpected EOF in SIGPROC integer")
                header[key] = struct.unpack("<i", payload)[0]
            elif key in _SIGPROC_DOUBLE_KEYS:
                payload = handle.read(8)
                if len(payload) != 8:
                    raise EOFError("Unexpected EOF in SIGPROC double")
                header[key] = struct.unpack("<d", payload)[0]
            else:
                raise ValueError(
                    f"Unsupported SIGPROC header key {key!r}; use blimpy/sigpyproc for uncommon extensions"
                )


def load_sigproc_filterbank(
    path: str | Path,
    *,
    start_sample: int = 0,
    max_samples: int | None = None,
) -> DynamicSpectrum:
    """Read a conventional SIGPROC ``.fil`` detected-power stream.

    Supports 8/16-bit integer and 32-bit floating-point samples. Uncommon packed
    1/2/4-bit modes intentionally fail loudly rather than silently misreading data.
    """

    path = Path(path)
    header, data_offset = read_sigproc_header(path)
    nchan = int(header.get("nchans", 0))
    nifs = int(header.get("nifs", 1))
    nbits = int(header.get("nbits", 0))
    if nchan <= 0 or nifs <= 0:
        raise ValueError("SIGPROC header must define positive nchans and nifs")

    signed = bool(header.get("signed", 0))
    dtype_map: dict[tuple[int, bool], np.dtype] = {
        (8, False): np.dtype("u1"),
        (8, True): np.dtype("i1"),
        (16, False): np.dtype("<u2"),
        (16, True): np.dtype("<i2"),
        (32, False): np.dtype("<f4"),
        (32, True): np.dtype("<f4"),
    }
    dtype = dtype_map.get((nbits, signed))
    if dtype is None:
        raise ValueError(f"Unsupported SIGPROC nbits={nbits}, signed={signed}")

    frame_items = nchan * nifs
    file_bytes = path.stat().st_size - data_offset
    n_total = file_bytes // (dtype.itemsize * frame_items)
    if start_sample < 0 or start_sample >= n_total:
        raise ValueError("start_sample outside file")
    n_read = n_total - start_sample if max_samples is None else min(max_samples, n_total - start_sample)
    offset = data_offset + start_sample * frame_items * dtype.itemsize
    flat = np.memmap(path, dtype=dtype, mode="r", offset=offset, shape=(n_read * frame_items,))
    data = np.asarray(flat).reshape(n_read, nifs, nchan).astype(np.float32)

    fch1 = float(header.get("fch1", 0.0))
    foff = float(header.get("foff", 0.0))
    tsamp = float(header.get("tsamp", 0.0))
    if tsamp <= 0 or fch1 == 0.0 or foff == 0.0:
        raise ValueError("SIGPROC header missing tsamp/fch1/foff")
    frequencies_hz = (fch1 + np.arange(nchan) * foff) * 1e6

    return DynamicSpectrum(
        data=data,
        tsamp_s=tsamp,
        frequencies_hz=frequencies_hz,
        source_id=str(header.get("source_name", path.stem)),
        start_mjd=float(header["tstart"]) if "tstart" in header else None,
        metadata={"format": "sigproc", "path": str(path), "header": header},
    )


def write_sigproc_filterbank(path: str | Path, spectrum: DynamicSpectrum, nbits: int = 32) -> None:
    """Write a small standards-compatible filterbank, mainly for tests and fixtures."""

    if nbits != 32:
        raise ValueError("fixture writer currently supports nbits=32 only")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    def write_string(handle, value: str) -> None:
        encoded = value.encode("ascii")
        handle.write(struct.pack("<i", len(encoded)))
        handle.write(encoded)

    freqs_mhz = spectrum.frequencies_hz / 1e6
    foff = float(np.median(np.diff(freqs_mhz))) if spectrum.n_chan > 1 else 1.0
    fields: list[tuple[str, Any, str]] = [
        ("source_name", spectrum.source_id, "s"),
        ("data_type", 1, "i"),
        ("nchans", spectrum.n_chan, "i"),
        ("nifs", spectrum.n_pol, "i"),
        ("nbits", 32, "i"),
        ("signed", 0, "i"),
        ("tsamp", spectrum.tsamp_s, "d"),
        ("fch1", float(freqs_mhz[0]), "d"),
        ("foff", foff, "d"),
    ]
    if spectrum.start_mjd is not None:
        fields.append(("tstart", spectrum.start_mjd, "d"))

    with path.open("wb") as handle:
        write_string(handle, "HEADER_START")
        for key, value, kind in fields:
            write_string(handle, key)
            if kind == "s":
                write_string(handle, str(value))
            elif kind == "i":
                handle.write(struct.pack("<i", int(value)))
            else:
                handle.write(struct.pack("<d", float(value)))
        write_string(handle, "HEADER_END")
        handle.write(np.asarray(spectrum.data, dtype="<f4").tobytes(order="C"))


def load_psrfits_search(
    path: str | Path,
    *,
    start_subint: int = 0,
    max_subints: int | None = None,
) -> DynamicSpectrum:
    """Load conventional search-mode PSRFITS via the optional ``astropy`` package.

    The adapter supports common SUBINT layouts and applies DAT_SCL, DAT_OFFS and
    DAT_WTS. Complex observatory-specific files should be normalized with PRESTO or
    PSRCHIVE first.
    """

    try:
        from astropy.io import fits  # type: ignore
    except ImportError as exc:
        raise RuntimeError("PSRFITS support requires: pip install 'pulsar-network-experiment[psrfits]'") from exc

    path = Path(path)
    with fits.open(path, memmap=True) as hdul:
        primary = hdul[0].header
        subint = hdul["SUBINT"]
        table = subint.data
        header = subint.header
        nchan = int(header["NCHAN"])
        npol = int(header["NPOL"])
        nsblk = int(header.get("NSBLK", 1))
        tbin = float(header["TBIN"])
        end = len(table) if max_subints is None else min(len(table), start_subint + max_subints)
        rows = table[start_subint:end]
        if len(rows) == 0:
            raise ValueError("No PSRFITS SUBINT rows selected")

        blocks: list[np.ndarray] = []
        for row in rows:
            raw = np.asarray(row["DATA"])
            if raw.size != nsblk * npol * nchan:
                raise ValueError(f"Unexpected PSRFITS DATA size {raw.size}")
            cube = raw.reshape(nsblk, npol, nchan).astype(np.float32)
            zero_offs = float(primary.get("ZERO_OFF", primary.get("ZERO_OFFS", 0.0)))
            scales = np.asarray(row["DAT_SCL"], dtype=np.float32).reshape(npol, nchan)
            offsets = np.asarray(row["DAT_OFFS"], dtype=np.float32).reshape(npol, nchan)
            weights = np.asarray(row["DAT_WTS"], dtype=np.float32).reshape(nchan)
            cube = (cube - zero_offs) * scales[None, :, :] + offsets[None, :, :]
            cube *= weights[None, None, :]
            blocks.append(cube)

        data = np.concatenate(blocks, axis=0)
        frequencies_hz = np.asarray(rows[0]["DAT_FREQ"], dtype=float) * 1e6
        source = str(primary.get("SRC_NAME", path.stem)).strip()
        imjd = primary.get("STT_IMJD")
        smjd = primary.get("STT_SMJD", 0.0)
        offs = primary.get("STT_OFFS", 0.0)
        start_mjd = None if imjd is None else float(imjd) + (float(smjd) + float(offs)) / 86400.0

    return DynamicSpectrum(
        data=data,
        tsamp_s=tbin,
        frequencies_hz=frequencies_hz,
        source_id=source,
        start_mjd=start_mjd,
        metadata={"format": "psrfits", "path": str(path)},
    )


def channel_rfi_mask(data: np.ndarray, z_threshold: float = 6.0) -> np.ndarray:
    """Return True for frequency channels with robustly anomalous level or variance."""

    power = np.asarray(data, dtype=float)
    if power.ndim == 3:
        power = power.mean(axis=1)
    med_level = np.median(power, axis=0)
    med = np.median(med_level)
    mad = np.median(np.abs(med_level - med)) + 1e-12
    level_z = np.abs(med_level - med) / (1.4826 * mad)

    channel_mad = np.median(np.abs(power - np.median(power, axis=0)), axis=0)
    var_med = np.median(channel_mad)
    var_mad = np.median(np.abs(channel_mad - var_med)) + 1e-12
    variance_z = np.abs(channel_mad - var_med) / (1.4826 * var_mad)
    return (level_z > z_threshold) | (variance_z > z_threshold) | ~np.isfinite(med_level)


def dedisperse_incoherent(
    data: np.ndarray,
    frequencies_hz: np.ndarray,
    tsamp_s: float,
    dm_pc_cm3: float,
) -> np.ndarray:
    """Integer-sample incoherent dedispersion, aligned to the highest frequency."""

    cube = np.asarray(data)
    if cube.ndim == 2:
        cube = cube[:, None, :]
    if dm_pc_cm3 == 0:
        return cube.copy()
    freqs_mhz = np.asarray(frequencies_hz, dtype=float) / 1e6
    ref = float(np.max(freqs_mhz))
    delays_s = DISPERSION_CONSTANT_S_MHZ2 * dm_pc_cm3 * (freqs_mhz ** -2 - ref ** -2)
    shifts = np.rint(delays_s / tsamp_s).astype(int)
    max_shift = int(np.max(shifts))
    if max_shift >= cube.shape[0] - 2:
        raise ValueError("Dispersion delay exceeds observation length")
    out_len = cube.shape[0] - max_shift
    out = np.empty((out_len, cube.shape[1], cube.shape[2]), dtype=cube.dtype)
    for channel, shift in enumerate(shifts):
        out[:, :, channel] = cube[shift : shift + out_len, :, channel]
    return out


def _robust_standardize_channels(power: np.ndarray, good: np.ndarray) -> np.ndarray:
    selected = power[:, good]
    med = np.median(selected, axis=0)
    mad = np.median(np.abs(selected - med), axis=0)
    scale = 1.4826 * mad
    scale[scale < 1e-8] = 1.0
    return (selected - med) / scale


def extract_pulse_train(
    spectrum: DynamicSpectrum,
    *,
    period_s: float,
    dm_pc_cm3: float = 0.0,
    on_window_fraction: float = 0.08,
    rfi_z_threshold: float = 6.0,
    window_phase_offset_fraction: float = 0.0,
) -> PulseTrain:
    """Convert a dynamic spectrum into one feature vector per pulsar rotation.

    This is a deliberately auditable baseline extractor. Precision work should later
    replace integer dedispersion and centroid timing with observatory-calibrated tools.
    """

    if period_s <= spectrum.tsamp_s * 4:
        raise ValueError("period must span at least four time samples")
    dedispersed = dedisperse_incoherent(
        spectrum.data, spectrum.frequencies_hz, spectrum.tsamp_s, dm_pc_cm3
    )
    rfi = channel_rfi_mask(dedispersed, z_threshold=rfi_z_threshold)
    good = ~rfi
    if np.sum(good) < max(2, spectrum.n_chan // 10):
        raise ValueError("Too many channels rejected as RFI")

    total_power = dedispersed[:, 0, :]
    normalized = _robust_standardize_channels(total_power, good)
    timeseries = np.mean(normalized, axis=1)

    period_samples = int(round(period_s / spectrum.tsamp_s))
    n_pulses = len(timeseries) // period_samples
    if n_pulses < 16:
        raise ValueError("Observation contains fewer than 16 complete rotations")
    trimmed = timeseries[: n_pulses * period_samples].reshape(n_pulses, period_samples)
    profile = np.median(trimmed, axis=0)
    detected_peak = int(np.argmax(profile))
    phase_shift = int(round(period_samples * window_phase_offset_fraction))
    peak = (detected_peak + phase_shift) % period_samples
    width = max(1, int(round(period_samples * on_window_fraction)))
    offsets = np.arange(-width // 2, width - width // 2)
    on_idx = (peak + offsets) % period_samples
    off_mask = np.ones(period_samples, dtype=bool)
    off_mask[on_idx] = False

    on_values = trimmed[:, on_idx]
    baseline = np.median(trimmed[:, off_mask], axis=1)
    amplitude = np.mean(on_values, axis=1) - baseline

    weights = np.maximum(on_values - baseline[:, None], 0.0)
    local_offsets = offsets.astype(float)
    denom = np.sum(weights, axis=1)
    centroid = np.divide(
        np.sum(weights * local_offsets[None, :], axis=1),
        denom,
        out=np.zeros(n_pulses),
        where=denom > 1e-12,
    )
    arrival_residual_s = centroid * spectrum.tsamp_s

    good_freqs = spectrum.frequencies_hz[good]
    channel_power = dedispersed[: n_pulses * period_samples, 0, :][:, good]
    channel_power = channel_power.reshape(n_pulses, period_samples, -1)[:, on_idx, :].mean(axis=1)
    channel_power -= np.median(channel_power, axis=1, keepdims=True)
    positive = np.maximum(channel_power, 0.0)
    freq_denom = positive.sum(axis=1)
    frequency_centroid_hz = np.divide(
        positive @ good_freqs,
        freq_denom,
        out=np.full(n_pulses, float(np.mean(good_freqs))),
        where=freq_denom > 1e-12,
    )

    polarization = np.zeros(n_pulses, dtype=float)
    if dedispersed.shape[1] >= 4:
        # Conventional I,Q,U,V ordering: retain signed circular fraction V/I.
        i_stream = dedispersed[: n_pulses * period_samples, 0, :][:, good]
        v_stream = dedispersed[: n_pulses * period_samples, 3, :][:, good]
        i_fold = i_stream.reshape(n_pulses, period_samples, -1)[:, on_idx, :].mean(axis=(1, 2))
        v_fold = v_stream.reshape(n_pulses, period_samples, -1)[:, on_idx, :].mean(axis=(1, 2))
        polarization = np.divide(v_fold, np.abs(i_fold), out=np.zeros_like(v_fold), where=np.abs(i_fold) > 1e-12)
        polarization = np.clip(polarization, -1.0, 1.0)
    elif dedispersed.shape[1] >= 2:
        a = dedispersed[: n_pulses * period_samples, 0, :][:, good]
        b = dedispersed[: n_pulses * period_samples, 1, :][:, good]
        a = a.reshape(n_pulses, period_samples, -1)[:, on_idx, :].mean(axis=(1, 2))
        b = b.reshape(n_pulses, period_samples, -1)[:, on_idx, :].mean(axis=(1, 2))
        polarization = np.divide(a - b, np.abs(a) + np.abs(b), out=np.zeros_like(a), where=(np.abs(a) + np.abs(b)) > 1e-12)

    source_id = spectrum.source_id
    return PulseTrain(
        period_s=period_s,
        amplitude=amplitude.astype(float),
        arrival_residual_s=arrival_residual_s.astype(float),
        polarization=polarization.astype(float),
        frequency_centroid_hz=frequency_centroid_hz.astype(float),
        source_id=source_id,
        metadata={
            "observation": dict(spectrum.metadata or {}),
            "start_mjd": spectrum.start_mjd,
            "tsamp_s": spectrum.tsamp_s,
            "n_channels": spectrum.n_chan,
            "n_polarizations": spectrum.n_pol,
            "dm_pc_cm3": dm_pc_cm3,
            "period_s": period_s,
            "period_samples": period_samples,
            "rfi_rejected_fraction": float(np.mean(rfi)),
            "detected_peak_sample": detected_peak,
            "analysis_window_peak_sample": peak,
            "window_phase_offset_fraction": window_phase_offset_fraction,
            "on_window_fraction": on_window_fraction,
        },
    )
