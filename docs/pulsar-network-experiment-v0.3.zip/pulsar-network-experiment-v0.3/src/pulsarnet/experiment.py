from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
import hashlib
import json

import numpy as np
import yaml

from .detector import benjamini_hochberg, scan_pulse_train
from .models import DetectionReport, PulseTrain
from .observations import (
    DynamicSpectrum,
    extract_pulse_train,
    load_hdf5_dynamic_spectrum,
    load_psrfits_search,
    load_sigproc_filterbank,
)


@dataclass(slots=True)
class ControlResult:
    control_id: str
    control_type: str
    parameters: dict[str, Any]
    pulse_train_path: str
    report: dict[str, Any]


@dataclass(slots=True)
class ObservationResult:
    observation_id: str
    source_id: str
    input_path: str
    input_sha256: str
    input_format: str
    target_pulse_train_path: str
    target_report: dict[str, Any]
    controls: list[dict[str, Any]]
    split_half: dict[str, Any]
    batch_fdr_q_value: float | None = None
    disposition: str = "pending_batch_correction"
    disposition_reasons: list[str] | None = None


@dataclass(slots=True)
class ExperimentResult:
    experiment_id: str
    manifest_path: str
    manifest_sha256: str
    seed: int
    surrogate_count: int
    observations: list[dict[str, Any]]
    summary: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def sha256_file(path: str | Path, chunk_bytes: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_bytes):
            digest.update(chunk)
    return digest.hexdigest()


def load_manifest(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in {".yaml", ".yml"}:
        payload = yaml.safe_load(text)
    else:
        payload = json.loads(text)
    if not isinstance(payload, dict):
        raise ValueError("experiment manifest must be a mapping")
    if not isinstance(payload.get("observations"), list) or not payload["observations"]:
        raise ValueError("manifest requires a non-empty observations list")
    return payload


def _load_dynamic(entry: dict[str, Any]) -> DynamicSpectrum:
    fmt = str(entry["format"]).lower()
    path = entry["path"]
    if fmt == "hdf5":
        return load_hdf5_dynamic_spectrum(
            path,
            start_sample=int(entry.get("start_sample", 0)),
            max_samples=entry.get("max_samples"),
        )
    if fmt == "filterbank":
        return load_sigproc_filterbank(
            path,
            start_sample=int(entry.get("start_sample", 0)),
            max_samples=entry.get("max_samples"),
        )
    if fmt == "psrfits":
        return load_psrfits_search(
            path,
            start_subint=int(entry.get("start_subint", 0)),
            max_subints=entry.get("max_subints"),
        )
    raise ValueError(f"{fmt!r} is not a dynamic-spectrum format")


def _extract(
    spectrum: DynamicSpectrum,
    entry: dict[str, Any],
    *,
    period_s: float | None = None,
    dm_pc_cm3: float | None = None,
    window_phase_offset_fraction: float = 0.0,
    label: str = "target",
) -> PulseTrain:
    train = extract_pulse_train(
        spectrum,
        period_s=float(period_s if period_s is not None else entry["period_s"]),
        dm_pc_cm3=float(dm_pc_cm3 if dm_pc_cm3 is not None else entry.get("dm_pc_cm3", 0.0)),
        on_window_fraction=float(entry.get("on_window_fraction", 0.08)),
        rfi_z_threshold=float(entry.get("rfi_z_threshold", 6.0)),
        window_phase_offset_fraction=window_phase_offset_fraction,
    )
    train.source_id = f"{spectrum.source_id}:{label}"
    train.metadata["analysis_label"] = label
    return train


def _slice_train(train: PulseTrain, start: int, stop: int, label: str) -> PulseTrain:
    return PulseTrain(
        period_s=train.period_s,
        amplitude=train.amplitude[start:stop],
        arrival_residual_s=train.arrival_residual_s[start:stop],
        polarization=train.polarization[start:stop],
        frequency_centroid_hz=train.frequency_centroid_hz[start:stop],
        source_id=f"{train.source_id}:{label}",
        metadata={**train.metadata, "slice": [start, stop], "analysis_label": label},
    )


def _block_permutation_control(train: PulseTrain, seed: int, block_size: int = 64) -> PulseTrain:
    """Permute aligned pulse blocks while preserving within-block natural texture."""
    rng = np.random.default_rng(seed)
    n = train.n_pulses
    blocks = [np.arange(start, min(start + block_size, n)) for start in range(0, n, block_size)]
    rng.shuffle(blocks)
    order = np.concatenate(blocks)
    out = PulseTrain(
        period_s=train.period_s,
        amplitude=train.amplitude[order],
        arrival_residual_s=train.arrival_residual_s[order],
        polarization=train.polarization[order],
        frequency_centroid_hz=train.frequency_centroid_hz[order],
        source_id=f"{train.source_id}:block-permutation",
        metadata={**train.metadata, "control_type": "block_permutation", "block_size": block_size},
    )
    return out


def _scan_and_save(
    train: PulseTrain,
    path: Path,
    surrogate_count: int,
    seed: int,
) -> DetectionReport:
    path.parent.mkdir(parents=True, exist_ok=True)
    train.save_npz(str(path))
    report = scan_pulse_train(train, surrogate_count=surrogate_count, seed=seed)
    path.with_suffix(".report.json").write_text(report.to_json(), encoding="utf-8")
    return report


def _is_level1(report: dict[str, Any]) -> bool:
    return bool(report["adjusted_p_value"] < 0.05 and report["compression_gain_bits"] > 128)


def _split_half_check(train: PulseTrain, surrogate_count: int, seed: int) -> dict[str, Any]:
    midpoint = train.n_pulses // 2
    if midpoint < 128 or train.n_pulses - midpoint < 128:
        return {"available": False, "reason": "fewer than 128 pulses per half"}
    first = scan_pulse_train(_slice_train(train, 0, midpoint, "first-half"), surrogate_count, seed)
    second = scan_pulse_train(_slice_train(train, midpoint, train.n_pulses, "second-half"), surrogate_count, seed + 1)
    lag_a, lag_b = first.strongest_lag, second.strongest_lag
    compatible = False
    if lag_a is not None and lag_b is not None:
        tolerance = max(3, int(max(lag_a, lag_b) * 0.03))
        compatible = abs(lag_a - lag_b) <= tolerance
    return {
        "available": True,
        "compatible_lag": compatible,
        "first": first.to_dict(),
        "second": second.to_dict(),
    }


def run_manifest(
    manifest_path: str | Path,
    *,
    output_dir: str | Path,
) -> ExperimentResult:
    manifest_path = Path(manifest_path).resolve()
    manifest = load_manifest(manifest_path)
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    experiment_id = str(manifest.get("experiment_id", manifest_path.stem))
    seed = int(manifest.get("seed", 20260804))
    surrogate_count = int(manifest.get("surrogate_count", 192))
    if surrogate_count < 24:
        raise ValueError("surrogate_count must be at least 24")

    raw_results: list[ObservationResult] = []
    for index, raw_entry in enumerate(manifest["observations"]):
        entry = dict(raw_entry)
        observation_id = str(entry.get("id", f"observation-{index:04d}"))
        input_path = Path(entry["path"])
        if not input_path.is_absolute():
            input_path = (manifest_path.parent / input_path).resolve()
        if not input_path.exists():
            raise FileNotFoundError(input_path)
        entry["path"] = str(input_path)
        fmt = str(entry["format"]).lower()
        obs_dir = output_dir / observation_id
        obs_dir.mkdir(parents=True, exist_ok=True)
        case_seed = seed + index * 10_000

        if fmt == "npz":
            target = PulseTrain.load_npz(str(input_path))
            target.source_id = f"{target.source_id}:target"
            dynamic = None
        else:
            dynamic = _load_dynamic(entry)
            target = _extract(dynamic, entry, label="target")

        target_path = obs_dir / "target.npz"
        target_report = _scan_and_save(target, target_path, surrogate_count, case_seed)
        controls: list[ControlResult] = []

        # A block-order control is available for every format and preserves local texture.
        block_size = int(entry.get("control_block_size", 64))
        shuffled = _block_permutation_control(target, case_seed + 100, block_size=block_size)
        control_path = obs_dir / "control-block-permutation.npz"
        report = _scan_and_save(shuffled, control_path, surrogate_count, case_seed + 101)
        controls.append(ControlResult(
            "block-permutation", "block_permutation", {"block_size": block_size}, str(control_path), report.to_dict()
        ))

        if dynamic is not None:
            period = float(entry["period_s"])
            dm = float(entry.get("dm_pc_cm3", 0.0))
            for cindex, offset in enumerate(entry.get("offpulse_phase_offsets", [0.25, 0.50, 0.75])):
                label = f"offpulse-{float(offset):+.3f}"
                control = _extract(dynamic, entry, window_phase_offset_fraction=float(offset), label=label)
                control_path = obs_dir / f"control-{label}.npz"
                report = _scan_and_save(control, control_path, surrogate_count, case_seed + 200 + cindex)
                controls.append(ControlResult(label, "offpulse", {"phase_offset_fraction": float(offset)}, str(control_path), report.to_dict()))

            for cindex, fraction in enumerate(entry.get("wrong_period_fractions", [-0.005, 0.005])):
                control_period = period * (1.0 + float(fraction))
                label = f"wrong-period-{float(fraction):+.5f}"
                control = _extract(dynamic, entry, period_s=control_period, label=label)
                control_path = obs_dir / f"control-{label}.npz"
                report = _scan_and_save(control, control_path, surrogate_count, case_seed + 300 + cindex)
                controls.append(ControlResult(label, "wrong_period", {"period_s": control_period}, str(control_path), report.to_dict()))

            if dm > 0:
                for cindex, fraction in enumerate(entry.get("wrong_dm_fractions", [-0.25, 0.25])):
                    control_dm = max(0.0, dm * (1.0 + float(fraction)))
                    label = f"wrong-dm-{float(fraction):+.3f}"
                    control = _extract(dynamic, entry, dm_pc_cm3=control_dm, label=label)
                    control_path = obs_dir / f"control-{label}.npz"
                    report = _scan_and_save(control, control_path, surrogate_count, case_seed + 400 + cindex)
                    controls.append(ControlResult(label, "wrong_dm", {"dm_pc_cm3": control_dm}, str(control_path), report.to_dict()))

        split_half = _split_half_check(target, max(24, surrogate_count // 2), case_seed + 500)
        raw_results.append(ObservationResult(
            observation_id=observation_id,
            source_id=target.source_id,
            input_path=str(input_path),
            input_sha256=sha256_file(input_path),
            input_format=fmt,
            target_pulse_train_path=str(target_path),
            target_report=target_report.to_dict(),
            controls=[asdict(item) for item in controls],
            split_half=split_half,
        ))

    q_values = benjamini_hochberg([item.target_report["adjusted_p_value"] for item in raw_results])
    candidate_count = 0
    for item, q_value in zip(raw_results, q_values):
        item.batch_fdr_q_value = float(q_value)
        reasons: list[str] = []
        target_l1 = _is_level1(item.target_report)
        contaminating = [
            control for control in item.controls
            if _is_level1(control["report"])
            or control["report"]["adjusted_p_value"] <= item.target_report["adjusted_p_value"]
        ]
        if not target_l1:
            item.disposition = "no_registered_level1_anomaly"
            reasons.append("Target does not meet adjusted-p and compression thresholds.")
        elif q_value >= 0.01:
            item.disposition = "level1_only_not_batch_significant"
            reasons.append("Target does not survive registered batch FDR q < 0.01.")
        elif contaminating:
            item.disposition = "rejected_by_negative_controls"
            reasons.append("One or more negative controls are at least as anomalous as the target.")
            reasons.extend(f"Control: {control['control_id']}" for control in contaminating)
        elif item.split_half.get("available") and not item.split_half.get("compatible_lag"):
            item.disposition = "not_replicated_across_split_halves"
            reasons.append("Strongest candidate lag is not compatible across held-out halves.")
        else:
            item.disposition = "follow_up_candidate"
            reasons.append("Survives registered software, batch and negative-control gates.")
            candidate_count += 1
        item.disposition_reasons = reasons

    minimum_adjusted_p = min(1.0, 4.0 / (surrogate_count + 1))
    single_candidate_q_floor = min(1.0, minimum_adjusted_p * len(raw_results))
    summary = {
        "observation_count": len(raw_results),
        "minimum_possible_channel_adjusted_p": minimum_adjusted_p,
        "single_candidate_batch_q_floor": single_candidate_q_floor,
        "registered_level1_p_threshold_resolvable": minimum_adjusted_p < 0.05,
        "registered_single_candidate_q_threshold_resolvable": single_candidate_q_floor < 0.01,
        "minimum_surrogates_for_single_candidate_q_below_0_01": max(1, 400 * len(raw_results)),
        "registered_level1_count": sum(_is_level1(item.target_report) for item in raw_results),
        "follow_up_candidate_count": candidate_count,
        "disposition_counts": {
            disposition: sum(item.disposition == disposition for item in raw_results)
            for disposition in sorted({item.disposition for item in raw_results})
        },
        "scientific_boundary": "A follow-up candidate is an anomaly requiring independent observatory and astrophysical validation, not evidence of extraterrestrial intelligence.",
    }
    result = ExperimentResult(
        experiment_id=experiment_id,
        manifest_path=str(manifest_path),
        manifest_sha256=sha256_file(manifest_path),
        seed=seed,
        surrogate_count=surrogate_count,
        observations=[asdict(item) for item in raw_results],
        summary=summary,
    )
    (output_dir / "experiment-report.json").write_text(json.dumps(result.to_dict(), indent=2), encoding="utf-8")
    return result
